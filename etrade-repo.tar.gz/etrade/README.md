# E*TRADE Trading Scripts

Python scripts for E*TRADE's live API: balances, 1DTE SPX option chain
scanning by delta, order placement/cancel/roll, and account risk
snapshots.

## Setup

```
python3.13 -m venv venv
source venv/bin/activate
pip install requests
```

Set your E*TRADE consumer key/secret (from the developer portal) as
environment variables — never commit these:

```
export ETRADE_CONSUMER_KEY="your_key"
export ETRADE_CONSUMER_SECRET="your_secret"
```

## Auth

E*TRADE uses OAuth 1.0a with an out-of-band callback — there's no way
around a one-time-per-day browser approval step. The first script you
run each day will open a browser, ask you to approve the app, and
prompt you to paste back a verification code. The resulting access
token is cached in `.etrade_token.json` (gitignored — it's a live
credential) and reused by every other script until it expires
(midnight ET, or 2 hours idle).

## Scripts

- `show_balance.py` — account balances
- `find_1dte_put.py` — scans the SPX 1DTE put chain for the strike
  closest to a target delta (default -0.01). `--order` lets you pick
  a strike from the results and go straight into the order flow.
- `place_order.py` — preview + place a single-leg option order.
  Requires typing "yes" after seeing real margin/BP numbers from
  E*TRADE. Also importable (`run_order_flow`) for other scripts to
  call in-process.
- `list_orders.py` — list open (or any status) orders
- `cancel_order.py` — cancel an order by ID, or browse open orders
  interactively
- `roll_order.py` — close an existing short put + open a new 1DTE
  strike as a single 2-leg spread order (net credit/debit)
- `risk_snapshot.py` — account-wide buying power / house excess
  equity snapshot, without needing an order in progress
- `diag_equity_preview.py` — diagnostic: previews a trivial 1-share
  equity order to check account-level order-placement permissions
- `etrade_auth.py` — OAuth 1.0a signing (shared)
- `etrade_common.py` — shared account/order/preview helpers (shared)

## Important symbol note

E*TRADE splits SPX into two different symbols depending on the
subsystem:
- **Market-data lookups** (chains, expiries, quotes) want the bare
  index ticker `SPX`.
- **Order placement** (buying/selling actual contracts) wants the
  tradable weekly root `SPXW`.

Scripts that need both (`roll_order.py`, `find_1dte_put.py --order`)
handle this conversion internally — but if you're extending these
scripts, don't assume one symbol works for both.

## Safety notes

- Every order-placing/cancelling/rolling script requires literally
  typing "yes" (or explicit confirmation) before doing anything
  irreversible. Nothing places or cancels silently.
- `--account-last4` (default `4422`) is required to match on every
  order script — it will refuse to guess which account to use.
- Preview numbers (margin impact, buying power) are E*TRADE's own
  real-time math. They do NOT reflect any separate after-the-fact
  house risk review E*TRADE may run — that isn't exposed by the
  public API.
